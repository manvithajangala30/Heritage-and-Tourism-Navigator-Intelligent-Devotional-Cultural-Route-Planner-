export type Language = "english" | "telugu" | "hindi" | "tamil" | "kannada";

export interface LanguageOption {
  code: Language;
  label: string;
  nativeLabel: string;
  speechLang: string;
}

export const languages: LanguageOption[] = [
  { code: "english", label: "English", nativeLabel: "English", speechLang: "en-IN" },
  { code: "telugu", label: "Telugu", nativeLabel: "తెలుగు", speechLang: "te-IN" },
  { code: "hindi", label: "Hindi", nativeLabel: "हिंदी", speechLang: "hi-IN" },
  { code: "tamil", label: "Tamil", nativeLabel: "தமிழ்", speechLang: "ta-IN" },
  { code: "kannada", label: "Kannada", nativeLabel: "ಕನ್ನಡ", speechLang: "kn-IN" },
];

export interface TempleTranslation {
  name: string;
  history: string;
  visitingHours: {
    general: string;
    special?: string;
  };
}

export const templeTranslations: Record<number, Record<Language, TempleTranslation>> = {
  1: {
    english: {
      name: "Sri Kalahasteeswara Swamy Temple",
      history: `Sacred Shaivite temple housing the Vayu Lingam, one of the Pancha Bhoota Sthalams. The temple's name derives from three devotees - Sri (spider), Kala (serpent), and Hasti (elephant) - who worshipped Lord Shiva and attained salvation. The magnificent gopuram was built by Krishnadevaraya in 1516 AD. World-famous for Rahu–Ketu dosha poojas that draw devotees seeking planetary remedies.`,
      visitingHours: {
        general: "6:00 AM – 9:00 PM",
        special: "Rahu–Ketu Pooja: 6:00 AM – 6:00 PM"
      }
    },
    telugu: {
      name: "శ్రీ కాళహస్తీశ్వర స్వామి దేవాలయం",
      history: `పంచభూత స్థలాలలో ఒకటైన వాయు లింగాన్ని కలిగి ఉన్న పవిత్ర శైవ ఆలయం. శ్రీ (సాలె పురుగు), కాల (పాము), హస్తి (ఏనుగు) అనే ముగ్గురు భక్తుల నుండి ఈ ఆలయానికి ఆ పేరు వచ్చింది - వారు శివుడిని పూజించి మోక్షం పొందారు. అద్భుతమైన గోపురాన్ని 1516 ADలో కృష్ణదేవరాయలు నిర్మించారు. గ్రహ దోషాల నివారణ కోసం రాహు-కేతు పూజలకు ప్రపంచ ప్రసిద్ధి.`,
      visitingHours: {
        general: "ఉదయం 6:00 – రాత్రి 9:00",
        special: "రాహు-కేతు పూజ: ఉదయం 6:00 – సాయంత్రం 6:00"
      }
    },
    hindi: {
      name: "श्री कालहस्तीश्वर स्वामी मंदिर",
      history: `पंचभूत स्थलों में से एक वायु लिंगम को समर्पित पवित्र शैव मंदिर। मंदिर का नाम तीन भक्तों - श्री (मकड़ी), काल (सांप), और हस्ती (हाथी) से लिया गया है - जिन्होंने भगवान शिव की पूजा की और मोक्ष प्राप्त किया। भव्य गोपुरम का निर्माण 1516 ई. में कृष्णदेवराय ने करवाया था। राहु-केतु दोष पूजा के लिए विश्व प्रसिद्ध।`,
      visitingHours: {
        general: "सुबह 6:00 – रात 9:00",
        special: "राहु-केतु पूजा: सुबह 6:00 – शाम 6:00"
      }
    },
    tamil: {
      name: "ஸ்ரீ காளஹஸ்தீஸ்வரர் கோயில்",
      history: `பஞ்ச பூத ஸ்தலங்களில் ஒன்றான வாயு லிங்கத்தை கொண்ட புனித சைவ கோயில். ஸ்ரீ (சிலந்தி), காலா (பாம்பு), ஹஸ்தி (யானை) ஆகிய மூன்று பக்தர்களின் பெயரிலிருந்து இந்த கோயிலுக்கு பெயர் வந்தது - அவர்கள் சிவபெருமானை வழிபட்டு முக்தி அடைந்தனர். 1516 ஆம் ஆண்டில் கிருஷ்ணதேவராயரால் அற்புதமான கோபுரம் கட்டப்பட்டது. ராகு-கேது தோஷ பூஜைகளுக்கு உலகப் புகழ் பெற்றது.`,
      visitingHours: {
        general: "காலை 6:00 – இரவு 9:00",
        special: "ராகு-கேது பூஜை: காலை 6:00 – மாலை 6:00"
      }
    },
    kannada: {
      name: "ಶ್ರೀ ಕಾಳಹಸ್ತೀಶ್ವರ ಸ್ವಾಮಿ ದೇವಾಲಯ",
      history: `ಪಂಚಭೂತ ಸ್ಥಳಗಳಲ್ಲಿ ಒಂದಾದ ವಾಯು ಲಿಂಗವನ್ನು ಹೊಂದಿರುವ ಪವಿತ್ರ ಶೈವ ದೇವಾಲಯ. ಶ್ರೀ (ಜೇಡ), ಕಾಲ (ಹಾವು), ಮತ್ತು ಹಸ್ತಿ (ಆನೆ) ಎಂಬ ಮೂವರು ಭಕ್ತರಿಂದ ದೇವಾಲಯಕ್ಕೆ ಹೆಸರು ಬಂದಿತು - ಅವರು ಶಿವನನ್ನು ಪೂಜಿಸಿ ಮೋಕ್ಷ ಪಡೆದರು. 1516 AD ಯಲ್ಲಿ ಕೃಷ್ಣದೇವರಾಯರಿಂದ ಅದ್ಭುತ ಗೋಪುರ ನಿರ್ಮಿಸಲಾಯಿತು. ರಾಹು-ಕೇತು ದೋಷ ಪೂಜೆಗಳಿಗೆ ವಿಶ್ವ ಪ್ರಸಿದ್ಧ.`,
      visitingHours: {
        general: "ಬೆಳಿಗ್ಗೆ 6:00 – ರಾತ್ರಿ 9:00",
        special: "ರಾಹು-ಕೇತು ಪೂಜೆ: ಬೆಳಿಗ್ಗೆ 6:00 – ಸಂಜೆ 6:00"
      }
    }
  },
  2: {
    english: {
      name: "Sri Varasiddhi Vinayaka Swamy Temple",
      history: `Home to the miraculous Swayambhu (self-manifested) idol of Lord Ganesha, discovered in a well by three physically challenged brothers. The idol is believed to continuously grow in size. Originally built by Chola king Kulottunga I in the 11th century and later expanded by Vijayanagara rulers. The temple attracts lakhs of devotees during Brahmotsavams.`,
      visitingHours: {
        general: "4:00 AM – 9:30 PM",
        special: "Special Abhishekam: Fridays & Vinayaka Chaturthi"
      }
    },
    telugu: {
      name: "శ్రీ వరసిద్ధి వినాయక స్వామి దేవాలయం",
      history: `ముగ్గురు అంగవైకల్యం ఉన్న సోదరులు బావిలో కనుగొన్న స్వయంభూ (స్వయంగా ఆవిర్భవించిన) వినాయకుని విగ్రహానికి నిలయం. ఈ విగ్రహం నిరంతరం పెరుగుతుందని నమ్ముతారు. మొదట 11వ శతాబ్దంలో చోళ రాజు కులోత్తుంగ I నిర్మించారు, తర్వాత విజయనగర రాజులు విస్తరించారు. బ్రహ్మోత్సవాల సమయంలో లక్షలాది భక్తులు వస్తారు.`,
      visitingHours: {
        general: "ఉదయం 4:00 – రాత్రి 9:30",
        special: "ప్రత్యేక అభిషేకం: శుక్రవారాలు & వినాయక చవితి"
      }
    },
    hindi: {
      name: "श्री वरसिद्धि विनायक स्वामी मंदिर",
      history: `तीन विकलांग भाइयों द्वारा कुएं में खोजी गई भगवान गणेश की चमत्कारी स्वयंभू मूर्ति का घर। माना जाता है कि मूर्ति का आकार लगातार बढ़ रहा है। मूलतः 11वीं शताब्दी में चोल राजा कुलोत्तुंग I द्वारा निर्मित और बाद में विजयनगर शासकों द्वारा विस्तारित। ब्रह्मोत्सव के दौरान लाखों भक्त आते हैं।`,
      visitingHours: {
        general: "सुबह 4:00 – रात 9:30",
        special: "विशेष अभिषेक: शुक्रवार और विनायक चतुर्थी"
      }
    },
    tamil: {
      name: "ஸ்ரீ வரசித்தி விநாயகர் கோயில்",
      history: `மூன்று உடல் ஊனமுற்ற சகோதரர்களால் கிணற்றில் கண்டுபிடிக்கப்பட்ட அற்புதமான சுயம்பு விநாயகர் சிலையின் இருப்பிடம். சிலை தொடர்ந்து வளர்வதாக நம்பப்படுகிறது. 11ஆம் நூற்றாண்டில் சோழ மன்னன் குலோத்துங்க I ஆல் கட்டப்பட்டு, பின்னர் விஜயநகர ஆட்சியாளர்களால் விரிவுபடுத்தப்பட்டது. பிரம்மோற்சவங்களின் போது லட்சக்கணக்கான பக்தர்களை ஈர்க்கிறது.`,
      visitingHours: {
        general: "காலை 4:00 – இரவு 9:30",
        special: "சிறப்பு அபிஷேகம்: வெள்ளிக்கிழமைகள் & விநாயகர் சதுர்த்தி"
      }
    },
    kannada: {
      name: "ಶ್ರೀ ವರಸಿದ್ಧಿ ವಿನಾಯಕ ಸ್ವಾಮಿ ದೇವಾಲಯ",
      history: `ಮೂವರು ಅಂಗವಿಕಲ ಸಹೋದರರು ಬಾವಿಯಲ್ಲಿ ಕಂಡುಹಿಡಿದ ಅದ್ಭುತ ಸ್ವಯಂಭೂ ಗಣೇಶ ಮೂರ್ತಿಯ ನೆಲೆ. ಮೂರ್ತಿಯು ನಿರಂತರವಾಗಿ ಬೆಳೆಯುತ್ತಿದೆ ಎಂದು ನಂಬಲಾಗಿದೆ. 11ನೇ ಶತಮಾನದಲ್ಲಿ ಚೋಳ ರಾಜ ಕುಲೋತ್ತುಂಗ I ರಿಂದ ನಿರ್ಮಿಸಲಾಯಿತು ಮತ್ತು ನಂತರ ವಿಜಯನಗರ ಆಡಳಿತಗಾರರಿಂದ ವಿಸ್ತರಿಸಲಾಯಿತು. ಬ್ರಹ್ಮೋತ್ಸವಗಳ ಸಮಯದಲ್ಲಿ ಲಕ್ಷಾಂತರ ಭಕ್ತರನ್ನು ಆಕರ್ಷಿಸುತ್ತದೆ.`,
      visitingHours: {
        general: "ಬೆಳಿಗ್ಗೆ 4:00 – ರಾತ್ರಿ 9:30",
        special: "ವಿಶೇಷ ಅಭಿಷೇಕ: ಶುಕ್ರವಾರಗಳು & ವಿನಾಯಕ ಚತುರ್ಥಿ"
      }
    }
  },
  3: {
    english: {
      name: "Kapila Theertham",
      history: `Sacred Shaivite temple nestled at the foothills of Tirumala hills. Named after Sage Kapila who performed severe penance here worshipping Lord Shiva. Features a beautiful natural waterfall that flows into the holy theertham (sacred tank). Recognized as one of the 108 sacred theerthams. Devotees traditionally visit here before ascending to Tirumala.`,
      visitingHours: {
        general: "5:00 AM – 8:30/9:00 PM"
      }
    },
    telugu: {
      name: "కపిల తీర్థం",
      history: `తిరుమల కొండల పాదాల వద్ద ఉన్న పవిత్ర శైవ ఆలయం. ఇక్కడ శివుడిని పూజిస్తూ తీవ్ర తపస్సు చేసిన కపిల మహర్షి పేరు మీద ఈ ఆలయానికి పేరు వచ్చింది. పవిత్ర తీర్థం (పవిత్ర కుండం) లోకి ప్రవహించే అందమైన సహజ జలపాతం ఉంది. 108 పవిత్ర తీర్థాలలో ఒకటిగా గుర్తించబడింది. భక్తులు తిరుమలకు వెళ్ళే ముందు ఇక్కడ సందర్శిస్తారు.`,
      visitingHours: {
        general: "ఉదయం 5:00 – రాత్రి 8:30/9:00"
      }
    },
    hindi: {
      name: "कपिल तीर्थम",
      history: `तिरुमला पहाड़ियों की तलहटी में बसा पवित्र शैव मंदिर। ऋषि कपिल के नाम पर, जिन्होंने यहां भगवान शिव की पूजा करते हुए कठोर तपस्या की। पवित्र तीर्थम (पवित्र तालाब) में बहने वाला सुंदर प्राकृतिक झरना है। 108 पवित्र तीर्थों में से एक। भक्त परंपरागत रूप से तिरुमला चढ़ने से पहले यहां आते हैं।`,
      visitingHours: {
        general: "सुबह 5:00 – रात 8:30/9:00"
      }
    },
    tamil: {
      name: "கபில தீர்த்தம்",
      history: `திருமலை மலையடிவாரத்தில் அமைந்துள்ள புனித சைவ கோயில். சிவபெருமானை வழிபட்டு கடுமையான தவம் செய்த கபில முனிவரின் பெயரில் அமைந்தது. புனித தீர்த்தத்தில் (புனித குளம்) பாயும் அழகான இயற்கை நீர்வீழ்ச்சி உள்ளது. 108 புனித தீர்த்தங்களில் ஒன்றாக அங்கீகரிக்கப்பட்டுள்ளது. பக்தர்கள் திருமலைக்கு ஏறுவதற்கு முன் பாரம்பரியமாக இங்கு வருவார்கள்.`,
      visitingHours: {
        general: "காலை 5:00 – இரவு 8:30/9:00"
      }
    },
    kannada: {
      name: "ಕಪಿಲ ತೀರ್ಥ",
      history: `ತಿರುಮಲ ಬೆಟ್ಟದ ತಪ್ಪಲಲ್ಲಿ ನೆಲೆಸಿರುವ ಪವಿತ್ರ ಶೈವ ದೇವಾಲಯ. ಶಿವನನ್ನು ಪೂಜಿಸುತ್ತಾ ಕಠಿಣ ತಪಸ್ಸು ಮಾಡಿದ ಕಪಿಲ ಋಷಿಯ ಹೆಸರಿನಲ್ಲಿ ಹೆಸರಿಸಲಾಗಿದೆ. ಪವಿತ್ರ ತೀರ್ಥಕ್ಕೆ (ಪವಿತ್ರ ಕೊಳ) ಹರಿಯುವ ಸುಂದರ ನೈಸರ್ಗಿಕ ಜಲಪಾತವಿದೆ. 108 ಪವಿತ್ರ ತೀರ್ಥಗಳಲ್ಲಿ ಒಂದಾಗಿ ಗುರುತಿಸಲಾಗಿದೆ. ಭಕ್ತರು ತಿರುಮಲಕ್ಕೆ ಹೋಗುವ ಮೊದಲು ಸಾಂಪ್ರದಾಯಿಕವಾಗಿ ಇಲ್ಲಿ ಭೇಟಿ ನೀಡುತ್ತಾರೆ.`,
      visitingHours: {
        general: "ಬೆಳಿಗ್ಗೆ 5:00 – ರಾತ್ರಿ 8:30/9:00"
      }
    }
  },
  4: {
    english: {
      name: "Govindaraja Swamy Temple",
      history: `One of the oldest and most significant Vaishnavite temples in Tirupati, consecrated in 1130 AD by the great saint Ramanujacharya. According to legend, Lord Govindaraja is the elder brother of Lord Venkateswara and was appointed to manage celestial wealth for the deity on Tirumala. The temple showcases exquisite Vijayanagara architecture.`,
      visitingHours: {
        general: "5:00 AM – 9:00 PM",
        special: "Short afternoon breaks for rituals"
      }
    },
    telugu: {
      name: "గోవిందరాజస్వామి దేవాలయం",
      history: `తిరుపతిలో అత్యంత పురాతన మరియు ముఖ్యమైన వైష్ణవ ఆలయాలలో ఒకటి, 1130 ADలో మహా సంత్ రామానుజాచార్యులు ప్రతిష్ఠించారు. పురాణాల ప్రకారం, గోవిందరాజస్వామి శ్రీ వెంకటేశ్వరుని అన్నయ్య, తిరుమలలో దేవుని దివ్య సంపదను నిర్వహించడానికి నియమించబడ్డారు. ఈ ఆలయం అద్భుతమైన విజయనగర శిల్పకళను ప్రదర్శిస్తుంది.`,
      visitingHours: {
        general: "ఉదయం 5:00 – రాత్రి 9:00",
        special: "మధ్యాహ్నం చిన్న విరామం"
      }
    },
    hindi: {
      name: "गोविंदराज स्वामी मंदिर",
      history: `तिरुपति में सबसे पुराने और महत्वपूर्ण वैष्णव मंदिरों में से एक, 1130 ई. में महान संत रामानुजाचार्य द्वारा प्रतिष्ठित। किंवदंती के अनुसार, भगवान गोविंदराज भगवान वेंकटेश्वर के बड़े भाई हैं और तिरुमला पर देवता की दिव्य संपत्ति का प्रबंधन करने के लिए नियुक्त किए गए थे। मंदिर में उत्कृष्ट विजयनगर वास्तुकला है।`,
      visitingHours: {
        general: "सुबह 5:00 – रात 9:00",
        special: "दोपहर में संक्षिप्त विराम"
      }
    },
    tamil: {
      name: "கோவிந்தராஜ சுவாமி கோயில்",
      history: `திருப்பதியில் உள்ள மிகப் பழமையான மற்றும் முக்கியமான வைஷ்ணவ கோயில்களில் ஒன்று, 1130 ஆம் ஆண்டில் மகா ஞானி ராமானுஜரால் பிரதிஷ்டை செய்யப்பட்டது. புராணத்தின்படி, கோவிந்தராஜர் வெங்கடேஸ்வரனின் மூத்த சகோதரர் மற்றும் திருமலையில் தெய்வீக செல்வத்தை நிர்வகிக்க நியமிக்கப்பட்டார். கோயில் அற்புதமான விஜயநகர கட்டிடக்கலையை வெளிப்படுத்துகிறது.`,
      visitingHours: {
        general: "காலை 5:00 – இரவு 9:00",
        special: "மதிய நேரத்தில் சிறிய இடைவெளி"
      }
    },
    kannada: {
      name: "ಗೋವಿಂದರಾಜಸ್ವಾಮಿ ದೇವಾಲಯ",
      history: `ತಿರುಪತಿಯಲ್ಲಿನ ಅತ್ಯಂತ ಹಳೆಯ ಮತ್ತು ಪ್ರಮುಖ ವೈಷ್ಣವ ದೇವಾಲಯಗಳಲ್ಲಿ ಒಂದು, 1130 AD ಯಲ್ಲಿ ಮಹಾ ಸಂತ ರಾಮಾನುಜಾಚಾರ್ಯರಿಂದ ಪ್ರತಿಷ್ಠಾಪಿಸಲಾಯಿತು. ಪುರಾಣದ ಪ್ರಕಾರ, ಗೋವಿಂದರಾಜಸ್ವಾಮಿ ವೆಂಕಟೇಶ್ವರನ ಹಿರಿಯ ಸಹೋದರ ಮತ್ತು ತಿರುಮಲದಲ್ಲಿ ದೇವರ ದಿವ್ಯ ಸಂಪತ್ತನ್ನು ನಿರ್ವಹಿಸಲು ನೇಮಿಸಲಾಯಿತು. ದೇವಾಲಯವು ಅದ್ಭುತ ವಿಜಯನಗರ ವಾಸ್ತುಶಿಲ್ಪವನ್ನು ಪ್ರದರ್ಶಿಸುತ್ತದೆ.`,
      visitingHours: {
        general: "ಬೆಳಿಗ್ಗೆ 5:00 – ರಾತ್ರಿ 9:00",
        special: "ಮಧ್ಯಾಹ್ನ ಚಿಕ್ಕ ವಿರಾಮ"
      }
    }
  },
  5: {
    english: {
      name: "Sri Venkateswara Swamy Temple & Shilathoranam",
      history: `The world-famous Sri Venkateswara Temple, perched atop the seven hills (Saptagiri) of the Eastern Ghats, is the richest and most visited religious shrine globally. Darshan is managed by TTD through token/slot system. Near the temple lies the Shilathoranam - a rare natural rock arch formation estimated to be 2.5 billion years old, declared a National Geo-Heritage Monument. The evening Aarti and legendary Laddu prasadam create an unforgettable spiritual experience.`,
      visitingHours: {
        general: "Darshan as per TTD slot/token",
        special: "Shilathoranam: 6:00 AM – 6:00 PM"
      }
    },
    telugu: {
      name: "శ్రీ వెంకటేశ్వర స్వామి ఆలయం & శిలాతోరణం",
      history: `తూర్పు కనుమల ఏడు కొండలపై (సప్తగిరి) ఉన్న ప్రపంచ ప్రసిద్ధ శ్రీ వెంకటేశ్వర ఆలయం, ప్రపంచంలోనే అత్యంత ధనిక మరియు ఎక్కువగా సందర్శించే మత పుణ్యక్షేత్రం. TTD టోకెన్/స్లాట్ వ్యవస్థ ద్వారా దర్శనం నిర్వహించబడుతుంది. ఆలయం సమీపంలో శిలాతోరణం ఉంది - 2.5 బిలియన్ సంవత్సరాల పురాతన అరుదైన సహజ రాతి తోరణం, జాతీయ భూ-వారసత్వ స్మారకంగా ప్రకటించబడింది. సాయంత్రం ఆరతి మరియు ప్రసిద్ధ లడ్డూ ప్రసాదం మరపురాని ఆధ్యాత్మిక అనుభవాన్ని అందిస్తాయి.`,
      visitingHours: {
        general: "TTD స్లాట్/టోకెన్ ప్రకారం దర్శనం",
        special: "శిలాతోరణం: ఉదయం 6:00 – సాయంత్రం 6:00"
      }
    },
    hindi: {
      name: "श्री वेंकटेश्वर स्वामी मंदिर और शिलाथोरणम",
      history: `पूर्वी घाट की सात पहाड़ियों (सप्तगिरि) पर स्थित विश्व प्रसिद्ध श्री वेंकटेश्वर मंदिर, विश्व का सबसे धनी और सबसे अधिक देखा जाने वाला धार्मिक स्थल है। दर्शन TTD द्वारा टोकन/स्लॉट प्रणाली से प्रबंधित है। मंदिर के पास शिलाथोरणम है - 2.5 अरब वर्ष पुरानी दुर्लभ प्राकृतिक चट्टान मेहराब, राष्ट्रीय भू-विरासत स्मारक घोषित। शाम की आरती और प्रसिद्ध लड्डू प्रसादम अविस्मरणीय आध्यात्मिक अनुभव प्रदान करते हैं।`,
      visitingHours: {
        general: "TTD स्लॉट/टोकन के अनुसार दर्शन",
        special: "शिलाथोरणम: सुबह 6:00 – शाम 6:00"
      }
    },
    tamil: {
      name: "ஸ்ரீ வெங்கடேஸ்வரர் கோயில் & சிலாதோரணம்",
      history: `கிழக்கு மலைத்தொடரின் ஏழு மலைகளின் (சப்தகிரி) மீது அமர்ந்திருக்கும் உலகப் புகழ் பெற்ற ஸ்ரீ வெங்கடேஸ்வரர் கோயில், உலகின் மிகவும் செல்வமிக்க மற்றும் அதிகம் பார்வையிடப்படும் மத ஆலயம். TTD டோக்கன்/ஸ்லாட் முறை மூலம் தரிசனம் நிர்வகிக்கப்படுகிறது. கோயிலுக்கு அருகில் சிலாதோரணம் உள்ளது - 2.5 பில்லியன் ஆண்டுகள் பழமையான அரிய இயற்கை பாறை வளைவு, தேசிய புவி-பாரம்பரிய நினைவுச்சின்னமாக அறிவிக்கப்பட்டுள்ளது. மாலை ஆரத்தி மற்றும் புகழ்பெற்ற லட்டு பிரசாதம் மறக்க முடியாத ஆன்மீக அனுபவத்தை உருவாக்குகின்றன.`,
      visitingHours: {
        general: "TTD ஸ்லாட்/டோக்கன் படி தரிசனம்",
        special: "சிலாதோரணம்: காலை 6:00 – மாலை 6:00"
      }
    },
    kannada: {
      name: "ಶ್ರೀ ವೆಂಕಟೇಶ್ವರ ಸ್ವಾಮಿ ದೇವಾಲಯ & ಶಿಲಾತೋರಣ",
      history: `ಪೂರ್ವ ಘಟ್ಟಗಳ ಏಳು ಬೆಟ್ಟಗಳ (ಸಪ್ತಗಿರಿ) ಮೇಲೆ ನೆಲೆಸಿರುವ ವಿಶ್ವ ಪ್ರಸಿದ್ಧ ಶ್ರೀ ವೆಂಕಟೇಶ್ವರ ದೇವಾಲಯ, ಜಾಗತಿಕವಾಗಿ ಅತ್ಯಂತ ಶ್ರೀಮಂತ ಮತ್ತು ಹೆಚ್ಚು ಭೇಟಿ ನೀಡುವ ಧಾರ್ಮಿಕ ಕ್ಷೇತ್ರ. TTD ಟೋಕನ್/ಸ್ಲಾಟ್ ವ್ಯವಸ್ಥೆಯ ಮೂಲಕ ದರ್ಶನ ನಿರ್ವಹಿಸಲಾಗುತ್ತದೆ. ದೇವಾಲಯದ ಬಳಿ ಶಿಲಾತೋರಣವಿದೆ - 2.5 ಬಿಲಿಯನ್ ವರ್ಷಗಳಷ್ಟು ಹಳೆಯ ಅಪರೂಪದ ನೈಸರ್ಗಿಕ ಬಂಡೆ ಕಮಾನು, ರಾಷ್ಟ್ರೀಯ ಭೂ-ಪರಂಪರೆ ಸ್ಮಾರಕವೆಂದು ಘೋಷಿಸಲಾಗಿದೆ. ಸಂಜೆ ಆರತಿ ಮತ್ತು ಪ್ರಸಿದ್ಧ ಲಡ್ಡು ಪ್ರಸಾದ ಮರೆಯಲಾಗದ ಆಧ್ಯಾತ್ಮಿಕ ಅನುಭವವನ್ನು ಸೃಷ್ಟಿಸುತ್ತವೆ.`,
      visitingHours: {
        general: "TTD ಸ್ಲಾಟ್/ಟೋಕನ್ ಪ್ರಕಾರ ದರ್ಶನ",
        special: "ಶಿಲಾತೋರಣ: ಬೆಳಿಗ್ಗೆ 6:00 – ಸಂಜೆ 6:00"
      }
    }
  }
};
