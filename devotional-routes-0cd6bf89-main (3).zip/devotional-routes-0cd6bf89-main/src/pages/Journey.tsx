import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import BackButton from "@/components/BackButton";
import MandalaPattern from "@/components/MandalaPattern";
import OilLamp from "@/components/OilLamp";
import { Calendar, Car, IndianRupee, Heart } from "lucide-react";

const journeyTypes = [
  { id: "spiritual", label: "Spiritual/Religious", icon: "🙏" },
  { id: "heritage", label: "Heritage & History", icon: "🏛" },
  { id: "photography", label: "Photography", icon: "📸" },
  { id: "family", label: "Family Trip", icon: "👨‍👩‍👧‍👦" },
];

const travelModes = [
  { value: "car", label: "Car/Self Drive" },
  { value: "bus", label: "Bus" },
  { value: "train", label: "Train" },
  { value: "flight", label: "Flight + Local Transport" },
];

const Journey = () => {
  const navigate = useNavigate();
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [travelMode, setTravelMode] = useState("");
  const [budget, setBudget] = useState("");
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [preferences, setPreferences] = useState("");

  const toggleJourneyType = (id: string) => {
    setSelectedTypes((prev) =>
      prev.includes(id) ? prev.filter((t) => t !== id) : [...prev, id]
    );
  };

  const handleContinue = () => {
    navigate("/plan", {
      state: { startDate, endDate, travelMode, budget, selectedTypes, preferences }
    });
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-b from-background via-parchment to-muted">
      <MandalaPattern />
      
      {/* Decorative Lamps */}
      <div className="absolute top-20 right-10 hidden lg:block">
        <OilLamp delay={0.3} />
      </div>
      <div className="absolute bottom-40 left-10 hidden lg:block">
        <OilLamp delay={0.6} />
      </div>

      {/* Rangoli Pattern Border */}
      <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-temple-gold via-temple-saffron to-temple-gold opacity-60" />

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <BackButton to="/" label="Back to Login" />
        </motion.div>

        <motion.div
          className="text-center mb-10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h1 className="text-3xl md:text-4xl font-heading font-bold text-primary mb-3">
            Plan Your Sacred Journey
          </h1>
          <p className="text-muted-foreground font-body text-lg">
            Tell us about your pilgrimage preferences
          </p>
          <div className="mt-4 flex justify-center items-center gap-2">
            <span className="h-px w-8 bg-temple-gold" />
            <span className="text-xl text-temple-gold">✦</span>
            <span className="h-px w-8 bg-temple-gold" />
          </div>
        </motion.div>

        {/* Form Cards */}
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Dates & Travel Card */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card variant="parchment">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <Calendar className="h-6 w-6 text-temple-gold" />
                  Travel Dates & Mode
                </CardTitle>
                <CardDescription>When and how would you like to travel?</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="startDate" className="font-heading">Start Date</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="endDate" className="font-heading">End Date</Label>
                    <Input
                      id="endDate"
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label className="font-heading flex items-center gap-2">
                      <Car className="h-4 w-4 text-temple-bronze" />
                      Mode of Travel
                    </Label>
                    <Select value={travelMode} onValueChange={setTravelMode}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your travel mode" />
                      </SelectTrigger>
                      <SelectContent>
                        {travelModes.map((mode) => (
                          <SelectItem key={mode.value} value={mode.value}>
                            {mode.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Budget Card */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card variant="parchment">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <IndianRupee className="h-6 w-6 text-temple-gold" />
                  Budget
                </CardTitle>
                <CardDescription>Set your approximate budget for the trip</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Label htmlFor="budget" className="font-heading">Budget (in ₹)</Label>
                  <Input
                    id="budget"
                    type="number"
                    placeholder="e.g., 15000"
                    value={budget}
                    onChange={(e) => setBudget(e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Journey Type Card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card variant="parchment">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <Heart className="h-6 w-6 text-temple-gold" />
                  Type of Journey
                </CardTitle>
                <CardDescription>Select all that apply to your pilgrimage</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid sm:grid-cols-2 gap-4">
                  {journeyTypes.map((type) => (
                    <motion.div
                      key={type.id}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className={`flex items-center space-x-3 p-4 rounded-lg border-2 cursor-pointer transition-all duration-200 ${
                        selectedTypes.includes(type.id)
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-temple-bronze/50"
                      }`}
                      onClick={() => toggleJourneyType(type.id)}
                    >
                      <Checkbox
                        checked={selectedTypes.includes(type.id)}
                        onCheckedChange={() => toggleJourneyType(type.id)}
                      />
                      <span className="text-2xl">{type.icon}</span>
                      <span className="font-heading text-foreground">{type.label}</span>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Preferences Card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card variant="parchment">
              <CardHeader>
                <CardTitle>Additional Preferences</CardTitle>
                <CardDescription>Any special requirements or wishes for your journey?</CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea
                  placeholder="e.g., Vegetarian food only, wheelchair accessibility needed, early morning temple visits preferred..."
                  value={preferences}
                  onChange={(e) => setPreferences(e.target.value)}
                  className="min-h-[120px] font-body"
                />
              </CardContent>
            </Card>
          </motion.div>

          {/* Continue Button */}
          <motion.div
            className="flex justify-center pt-6 pb-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
          >
            <Button variant="temple" size="xl" onClick={handleContinue}>
              Continue to Trip Planning
            </Button>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Journey;
