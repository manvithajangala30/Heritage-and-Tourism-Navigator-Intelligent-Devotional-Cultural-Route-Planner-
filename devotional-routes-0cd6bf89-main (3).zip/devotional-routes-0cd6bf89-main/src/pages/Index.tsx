import { useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import OilLamp from "@/components/OilLamp";
import TempleBell from "@/components/TempleBell";
import MandalaPattern from "@/components/MandalaPattern";
import GopuramSilhouette from "@/components/GopuramSilhouette";
import { LogIn, LogOut, User } from "lucide-react";

const Index = () => {
  const navigate = useNavigate();
  const { user, loading, signOut } = useAuth();

  const handleLogout = async () => {
    await signOut();
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-b from-background via-parchment to-muted">
      {/* Animated Background Elements */}
      <MandalaPattern />
      <GopuramSilhouette />
      
      {/* Floating Oil Lamps */}
      <div className="absolute top-20 left-10 hidden md:block">
        <OilLamp delay={0.2} />
      </div>
      <div className="absolute top-32 right-16 hidden md:block">
        <OilLamp delay={0.5} />
      </div>
      <div className="absolute bottom-40 left-20 hidden lg:block">
        <OilLamp delay={0.8} />
      </div>
      <div className="absolute bottom-60 right-24 hidden lg:block">
        <OilLamp delay={1.1} />
      </div>
      
      {/* Temple Bells */}
      <div className="absolute top-10 left-1/4 hidden md:block">
        <TempleBell delay={0.3} />
      </div>
      <div className="absolute top-16 right-1/4 hidden md:block">
        <TempleBell delay={0.6} />
      </div>

      {/* Auth Status Bar */}
      <div className="absolute top-4 right-4 z-20">
        {loading ? (
          <div className="animate-pulse bg-muted/50 rounded-lg px-4 py-2">Loading...</div>
        ) : user ? (
          <div className="flex items-center gap-3 bg-card/80 backdrop-blur-sm rounded-lg px-4 py-2 shadow-md border border-primary/20">
            <div className="flex items-center gap-2 text-sm text-foreground">
              <User className="h-4 w-4 text-primary" />
              <span className="max-w-[150px] truncate">{user.email}</span>
            </div>
            <Button variant="outline" size="sm" onClick={handleLogout} className="gap-1">
              <LogOut className="h-4 w-4" />
              Logout
            </Button>
          </div>
        ) : (
          <Link to="/auth">
            <Button variant="temple" size="sm" className="gap-2">
              <LogIn className="h-4 w-4" />
              Login / Sign Up
            </Button>
          </Link>
        )}
      </div>

      {/* Main Content */}
      <div className="relative z-10 flex min-h-screen items-center justify-center px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="w-full max-w-md"
        >
          {/* Title Section */}
          <motion.div
            className="text-center mb-8"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-5xl font-heading font-bold text-primary mb-3 text-temple-shadow">
              Heritage and Tourism Navigator
            </h1>
            <p className="text-lg text-muted-foreground font-body italic">
              Begin Your Sacred Pilgrimage to Tirupati
            </p>
            <div className="mt-4 flex justify-center items-center gap-2">
              <span className="h-px w-12 bg-temple-gold" />
              <span className="text-2xl text-temple-gold">🙏</span>
              <span className="h-px w-12 bg-temple-gold" />
            </div>
          </motion.div>

          {/* Welcome Card */}
          <Card variant="parchment" className="border-2 border-temple-bronze/20">
            <CardHeader className="text-center pb-4">
              <CardTitle className="text-2xl">
                {user ? `Welcome, Pilgrim` : "Sacred Journey Awaits"}
              </CardTitle>
              <CardDescription className="text-base">
                {user 
                  ? "Continue your spiritual exploration"
                  : "Sign in to begin your spiritual journey"
                }
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {user ? (
                <>
                  <p className="text-center text-muted-foreground text-sm mb-4">
                    Logged in as: <span className="font-medium text-foreground">{user.email}</span>
                  </p>
                  <Button 
                    variant="temple" 
                    size="lg" 
                    className="w-full"
                    onClick={() => navigate("/journey")}
                  >
                    Begin Journey
                  </Button>
                </>
              ) : (
                <>
                  <p className="text-center text-muted-foreground text-sm mb-4">
                    Please sign in with your email and password to access the temple guide.
                  </p>
                  <Link to="/auth" className="block">
                    <Button variant="temple" size="lg" className="w-full gap-2">
                      <LogIn className="h-5 w-5" />
                      Login / Create Account
                    </Button>
                  </Link>
                </>
              )}

              <div className="mt-6 text-center">
                <p className="text-sm text-muted-foreground font-body">
                  "The journey of a thousand miles begins with a single step"
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Decorative Footer */}
          <motion.div
            className="mt-8 text-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
          >
            <p className="text-xs text-muted-foreground">
              🛕 Discover the divine heritage of South India 🛕
            </p>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
};

export default Index;
