import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import BackButton from "@/components/BackButton";
import MandalaPattern from "@/components/MandalaPattern";
import OilLamp from "@/components/OilLamp";
import { MapPin, Navigation, Sparkles } from "lucide-react";

const Plan = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [startingLocation, setStartingLocation] = useState("");

  const handleViewRoute = () => {
    navigate("/route", {
      state: { 
        ...location.state,
        startingLocation,
        destination: "Tirupati"
      }
    });
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-b from-background via-parchment to-muted">
      <MandalaPattern />
      
      {/* Decorative Elements */}
      <div className="absolute top-24 left-10 hidden lg:block">
        <OilLamp delay={0.3} />
      </div>
      <div className="absolute top-20 right-16 hidden lg:block">
        <OilLamp delay={0.5} />
      </div>

      {/* Animated Rangoli Top Border */}
      <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-temple-gold via-temple-saffron to-temple-gold opacity-60" />

      {/* Animated dancer silhouettes */}
      <motion.div
        className="absolute bottom-20 left-10 opacity-10 hidden lg:block"
        animate={{ y: [0, -10, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
      >
        <svg viewBox="0 0 100 150" className="w-24 h-36" fill="currentColor">
          <ellipse cx="50" cy="20" rx="12" ry="15" />
          <path d="M50 35 L50 80 M30 60 L70 60 M50 80 L30 130 M50 80 L70 130" 
                stroke="currentColor" strokeWidth="4" fill="none" />
        </svg>
      </motion.div>
      <motion.div
        className="absolute bottom-32 right-16 opacity-10 hidden lg:block"
        animate={{ y: [0, -8, 0] }}
        transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
      >
        <svg viewBox="0 0 100 150" className="w-20 h-32" fill="currentColor">
          <ellipse cx="50" cy="20" rx="10" ry="13" />
          <path d="M50 33 L50 75 M35 55 L65 55 M50 75 L35 120 M50 75 L65 120" 
                stroke="currentColor" strokeWidth="3" fill="none" />
        </svg>
      </motion.div>

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <BackButton to="/journey" label="Back to Journey Details" />
        </motion.div>

        <motion.div
          className="text-center mb-10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h1 className="text-3xl md:text-4xl font-heading font-bold text-primary mb-3">
            Plan Your Route
          </h1>
          <p className="text-muted-foreground font-body text-lg">
            Set your starting point for the sacred journey to Tirupati
          </p>
          <div className="mt-4 flex justify-center items-center gap-2">
            <span className="h-px w-8 bg-temple-gold" />
            <Sparkles className="h-5 w-5 text-temple-gold" />
            <span className="h-px w-8 bg-temple-gold" />
          </div>
        </motion.div>

        <div className="max-w-2xl mx-auto space-y-8">
          {/* Starting Location Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
          >
            <Card variant="parchment" className="border-2 border-temple-bronze/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <MapPin className="h-6 w-6 text-temple-saffron" />
                  Starting Location
                </CardTitle>
                <CardDescription>
                  Where will your pilgrimage begin?
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="startLocation" className="font-heading">
                    Enter your city or town
                  </Label>
                  <Input
                    id="startLocation"
                    placeholder="e.g., Chennai, Bangalore, Hyderabad..."
                    value={startingLocation}
                    onChange={(e) => setStartingLocation(e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Destination Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
          >
            <Card variant="temple" className="border-2 border-primary/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-primary">
                  <Navigation className="h-6 w-6 text-temple-gold" />
                  Sacred Destination
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-temple-gold/20 flex items-center justify-center">
                    <span className="text-3xl">🛕</span>
                  </div>
                  <div>
                    <h3 className="text-2xl font-heading font-bold text-primary">
                      Tirupati
                    </h3>
                    <p className="text-muted-foreground font-body">
                      Sri Venkateswara Temple, Tirumala
                    </p>
                    <p className="text-sm text-temple-bronze mt-1">
                      One of the holiest pilgrimage sites in India
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Route Preview */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="flex items-center justify-center gap-4 py-6"
          >
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-temple-bronze/20 flex items-center justify-center mx-auto mb-2">
                <MapPin className="h-6 w-6 text-temple-bronze" />
              </div>
              <p className="font-heading text-sm text-foreground">
                {startingLocation || "Your City"}
              </p>
            </div>
            
            <motion.div
              className="flex-1 max-w-32 relative"
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <div className="h-0.5 bg-gradient-to-r from-temple-bronze via-temple-gold to-temple-saffron" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                <motion.span
                  animate={{ x: [-20, 20, -20] }}
                  transition={{ duration: 3, repeat: Infinity }}
                  className="text-lg"
                >
                  🚗
                </motion.span>
              </div>
            </motion.div>
            
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-temple-gold/30 flex items-center justify-center mx-auto mb-2">
                <span className="text-xl">🛕</span>
              </div>
              <p className="font-heading text-sm text-foreground">Tirupati</p>
            </div>
          </motion.div>

          {/* Heritage Stops Preview */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card variant="parchment">
              <CardHeader>
                <CardTitle className="text-lg">Sacred Stops Along the Way</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {["Srikalahasthi", "Kanipakam", "Kapila Theertham", "Govindaraja Swamy Temple", "Tirumala & Shilathoranam"].map((stop, i) => (
                    <motion.span
                      key={stop}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.7 + i * 0.1 }}
                      className="px-3 py-1 bg-temple-gold/20 text-temple-bronze rounded-full text-sm font-body"
                    >
                      {stop}
                    </motion.span>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* View Route Button */}
          <motion.div
            className="flex justify-center pt-6 pb-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
          >
            <Button 
              variant="temple" 
              size="xl" 
              onClick={handleViewRoute}
              disabled={!startingLocation}
            >
              View Route & Stories
            </Button>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Plan;
