import { useState } from "react";
import { useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import BackButton from "@/components/BackButton";
import VoiceReader from "@/components/VoiceReader";
import LanguageSelector from "@/components/LanguageSelector";
import MandalaPattern from "@/components/MandalaPattern";
import OilLamp from "@/components/OilLamp";
import { useToast } from "@/hooks/use-toast";
import { 
  MapPin, Navigation, ChevronDown, ChevronUp, Hotel, 
  Utensils, Bus, Headphones, ExternalLink, MessageSquare,
  Building, Accessibility, Clock, Phone, Map
} from "lucide-react";
import { Language, languages, templeTranslations } from "@/data/templeTranslations";

import srikalahastiImg from "@/assets/srikalahasti-temple.jpg";
import kanipakamImg from "@/assets/kanipakam-temple.jpg";
import kapilaImg from "@/assets/kapila-theertham.jpg";
import govindarajaImg from "@/assets/govindaraja-temple.jpg";
import tirumalaImg from "@/assets/tirumala-temple.jpg";

interface TempleLocation {
  id: number;
  name: string;
  location: string;
  category: "temple" | "heritage";
  image: string;
  history: string;
  visitingHours: {
    general: string;
    special?: string;
  };
  hotels: Array<{
    name: string;
    contact: string;
  }>;
  restaurants: string[];
  facilities: {
    temple: boolean;
    heritage: boolean;
    stay: boolean;
    food: boolean;
    facilities: boolean;
    transport: boolean;
    audio: boolean;
  };
}

const templeLocations: TempleLocation[] = [
  {
    id: 1,
    name: "Sri Kalahasteeswara Swamy Temple",
    location: "Srikalahasti, Andhra Pradesh",
    category: "temple",
    image: srikalahastiImg,
    history: `Sacred Shaivite temple housing the Vayu Lingam, one of the Pancha Bhoota Sthalams. The temple's name derives from three devotees - Sri (spider), Kala (serpent), and Hasti (elephant) - who worshipped Lord Shiva and attained salvation. The magnificent gopuram was built by Krishnadevaraya in 1516 AD. World-famous for Rahu–Ketu dosha poojas that draw devotees seeking planetary remedies.`,
    visitingHours: {
      general: "6:00 AM – 9:00 PM",
      special: "Rahu–Ketu Pooja: 6:00 AM – 6:00 PM"
    },
    hotels: [
      { name: "MGM Grand", contact: "+91 877 228 5555" },
      { name: "KCR Grand", contact: "+91 877 228 6666" },
      { name: "SSR Hotel", contact: "+91 94403 83339" },
      { name: "Hotel Jayaam", contact: "+91 877 228 7777" }
    ],
    restaurants: [
      "Sri Lakshmi Narayana Bhavan (Pure Veg)",
      "Sai Priya Restaurant (Multi-cuisine)",
      "Traditional Andhra Messes (Local Cuisine)"
    ],
    facilities: { temple: true, heritage: true, stay: true, food: true, facilities: true, transport: true, audio: true }
  },
  {
    id: 2,
    name: "Sri Varasiddhi Vinayaka Swamy Temple",
    location: "Kanipakam, Chittoor District",
    category: "temple",
    image: kanipakamImg,
    history: `Home to the miraculous Swayambhu (self-manifested) idol of Lord Ganesha, discovered in a well by three physically challenged brothers. The idol is believed to continuously grow in size. Originally built by Chola king Kulottunga I in the 11th century and later expanded by Vijayanagara rulers. The temple attracts lakhs of devotees during Brahmotsavams.`,
    visitingHours: {
      general: "4:00 AM – 9:30 PM",
      special: "Special Abhishekam: Fridays & Vinayaka Chaturthi"
    },
    hotels: [
      { name: "Varasiddhi Vinayaka Residency", contact: "+91 8577 281111" },
      { name: "Mamidi Resort", contact: "+91 91777 11111" },
      { name: "Sindhu Towers", contact: "+91 8572 234567" },
      { name: "Prabaa Royal Park", contact: "+91 8572 222999" }
    ],
    restaurants: [
      "Temple Area Eateries (Idli, Dosa, Pongal)",
      "Traditional South Indian Meals",
      "Better Dining Available in Chittoor Town"
    ],
    facilities: { temple: true, heritage: true, stay: true, food: true, facilities: true, transport: true, audio: true }
  },
  {
    id: 3,
    name: "Kapila Theertham",
    location: "Tirupati, Andhra Pradesh",
    category: "heritage",
    image: kapilaImg,
    history: `Sacred Shaivite temple nestled at the foothills of Tirumala hills. Named after Sage Kapila who performed severe penance here worshipping Lord Shiva. Features a beautiful natural waterfall that flows into the holy theertham (sacred tank). Recognized as one of the 108 sacred theerthams. Devotees traditionally visit here before ascending to Tirumala.`,
    visitingHours: {
      general: "5:00 AM – 8:30/9:00 PM"
    },
    hotels: [
      { name: "Taj Tirupati", contact: "+91 877 225 6666" },
      { name: "Marasa Sarovar Premiere", contact: "+91 877 226 3333" },
      { name: "Ekante Bliss", contact: "+91 877 228 8888" },
      { name: "Springs Hotel", contact: "+91 877 222 4000" }
    ],
    restaurants: [
      "Gufha (Multi-cuisine)",
      "Minerva Coffee Shop (Pure Veg)",
      "Southern Spice (South Indian Specialties)"
    ],
    facilities: { temple: true, heritage: true, stay: true, food: true, facilities: true, transport: true, audio: true }
  },
  {
    id: 4,
    name: "Govindaraja Swamy Temple",
    location: "Tirupati Town Center",
    category: "temple",
    image: govindarajaImg,
    history: `One of the oldest and most significant Vaishnavite temples in Tirupati, consecrated in 1130 AD by the great saint Ramanujacharya. According to legend, Lord Govindaraja is the elder brother of Lord Venkateswara and was appointed to manage celestial wealth for the deity on Tirumala. The temple showcases exquisite Vijayanagara architecture.`,
    visitingHours: {
      general: "5:00 AM – 9:00 PM",
      special: "Short afternoon breaks for rituals"
    },
    hotels: [
      { name: "Best Western", contact: "+91 877 222 7777" },
      { name: "Golden Pearl Inn", contact: "+91 877 228 9000" },
      { name: "Iris Hotel", contact: "+91 877 228 8080" }
    ],
    restaurants: [
      "Green Meridian (Pure Veg Multi-cuisine)",
      "Plantain Leaf (Authentic South Indian)",
      "Local Eateries near Railway Station"
    ],
    facilities: { temple: true, heritage: true, stay: true, food: true, facilities: true, transport: true, audio: true }
  },
  {
    id: 5,
    name: "Sri Venkateswara Swamy Temple & Shilathoranam",
    location: "Tirumala, Andhra Pradesh",
    category: "heritage",
    image: tirumalaImg,
    history: `The world-famous Sri Venkateswara Temple, perched atop the seven hills (Saptagiri) of the Eastern Ghats, is the richest and most visited religious shrine globally. Darshan is managed by TTD through token/slot system. Near the temple lies the Shilathoranam - a rare natural rock arch formation estimated to be 2.5 billion years old, declared a National Geo-Heritage Monument. The evening Aarti and legendary Laddu prasadam create an unforgettable spiritual experience.`,
    visitingHours: {
      general: "Darshan as per TTD slot/token",
      special: "Shilathoranam: 6:00 AM – 6:00 PM"
    },
    hotels: [
      { name: "TTD Guest Houses & Cottages", contact: "Book via TTD Website/App" },
      { name: "Limited Private Lodging", contact: "Check local availability" }
    ],
    restaurants: [
      "TTD Anna Prasadam (Free Meals)",
      "TTD Canteens (Subsidized Veg Food)",
      "Small Vegetarian Eateries on Tirumala"
    ],
    facilities: { temple: true, heritage: true, stay: true, food: true, facilities: true, transport: true, audio: true }
  }
];

const FacilityIcon = ({ type, active }: { type: string; active: boolean }) => {
  const iconClass = `h-5 w-5 ${active ? "text-temple-gold" : "text-muted-foreground/40"}`;
  
  const icons: Record<string, JSX.Element> = {
    temple: <span className={`text-lg ${active ? "" : "opacity-40"}`}>🛕</span>,
    heritage: <Building className={iconClass} />,
    stay: <Hotel className={iconClass} />,
    food: <Utensils className={iconClass} />,
    facilities: <Accessibility className={iconClass} />,
    transport: <Bus className={iconClass} />,
    audio: <Headphones className={iconClass} />,
  };
  
  return (
    <div className="flex flex-col items-center gap-1" title={type}>
      {icons[type]}
    </div>
  );
};

const Route = () => {
  const location = useLocation();
  const { startingLocation = "Your Location" } = location.state || {};
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [feedbackName, setFeedbackName] = useState("");
  const [feedbackEmail, setFeedbackEmail] = useState("");
  const [feedbackComments, setFeedbackComments] = useState("");
  const [selectedLanguage, setSelectedLanguage] = useState<Language>("english");
  const { toast } = useToast();

  // Get the speech language code for TTS
  const getSpeechLang = () => {
    return languages.find(l => l.code === selectedLanguage)?.speechLang || "en-IN";
  };

  // Get translated content for a temple
  const getTranslatedContent = (templeId: number) => {
    return templeTranslations[templeId]?.[selectedLanguage] || templeTranslations[templeId]?.english;
  };

  const googleMapsUrl = `https://www.google.com/maps/dir/${encodeURIComponent(startingLocation)}/Tirupati,+Andhra+Pradesh`;

  const handleFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "🙏 Thank You!",
      description: "Your feedback has been received. May your journey be blessed.",
    });
    setFeedbackOpen(false);
    setFeedbackName("");
    setFeedbackEmail("");
    setFeedbackComments("");
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-b from-background via-parchment to-muted">
      <MandalaPattern />
      
      {/* Decorative Lamps */}
      <div className="absolute top-24 right-10 hidden xl:block">
        <OilLamp delay={0.3} />
      </div>

      {/* Top Border */}
      <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-temple-gold via-temple-saffron to-temple-gold opacity-60" />

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-wrap gap-4 justify-between items-center mb-8"
        >
          <BackButton to="/plan" label="Back to Planning" />
          
          <Dialog open={feedbackOpen} onOpenChange={setFeedbackOpen}>
            <DialogTrigger asChild>
              <Button variant="gold" className="gap-2">
                <MessageSquare className="h-4 w-4" />
                Give Feedback
              </Button>
            </DialogTrigger>
            <DialogContent className="parchment-card">
              <DialogHeader>
                <DialogTitle className="font-heading text-primary">Share Your Feedback</DialogTitle>
                <DialogDescription>
                  Help us improve your pilgrimage experience
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleFeedbackSubmit} className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="feedbackName">Name</Label>
                  <Input 
                    id="feedbackName" 
                    value={feedbackName}
                    onChange={(e) => setFeedbackName(e.target.value)}
                    required 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="feedbackEmail">Email</Label>
                  <Input 
                    id="feedbackEmail" 
                    type="email"
                    value={feedbackEmail}
                    onChange={(e) => setFeedbackEmail(e.target.value)}
                    required 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="feedbackComments">Your Comments</Label>
                  <Textarea 
                    id="feedbackComments"
                    value={feedbackComments}
                    onChange={(e) => setFeedbackComments(e.target.value)}
                    placeholder="Share your thoughts about your journey..."
                    required
                  />
                </div>
                <Button type="submit" variant="temple" className="w-full">
                  Submit Feedback
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </motion.div>

        <motion.div
          className="text-center mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h1 className="text-3xl md:text-4xl font-heading font-bold text-primary mb-3">
            Your Sacred Route
          </h1>
          <p className="text-muted-foreground font-body text-lg mb-4">
            From {startingLocation} to Tirupati
          </p>
          
          {/* Language Selector */}
          <div className="flex justify-center">
            <LanguageSelector 
              selectedLanguage={selectedLanguage}
              onLanguageChange={setSelectedLanguage}
            />
          </div>
        </motion.div>

        {/* Google Maps Section */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="max-w-4xl mx-auto mb-8"
        >
          <Card variant="parchment" className="overflow-hidden">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-3">
                <Navigation className="h-6 w-6 text-temple-saffron" />
                Route Map
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="aspect-video bg-muted relative">
                <iframe
                  src={`https://www.google.com/maps/embed/v1/directions?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&origin=${encodeURIComponent(startingLocation)}&destination=Tirupati,Andhra+Pradesh&mode=driving`}
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="absolute inset-0"
                />
              </div>
              <div className="p-4 flex flex-wrap gap-4 justify-between items-center">
                <div className="flex items-center gap-3">
                  <MapPin className="h-5 w-5 text-temple-bronze" />
                  <span className="font-body">{startingLocation}</span>
                  <span className="text-temple-gold">→</span>
                  <span className="text-xl">🛕</span>
                  <span className="font-body">Tirupati</span>
                </div>
                <a
                  href={googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button variant="gold" className="gap-2">
                    Open in Google Maps
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </a>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Hierarchical Root Map */}
        <div className="max-w-5xl mx-auto space-y-8">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-center mb-8"
          >
            <h2 className="text-2xl md:text-3xl font-heading font-semibold text-primary mb-2">
              Sacred Temple Root Map
            </h2>
            <p className="text-muted-foreground font-body">
              Complete guide to temples, timings, accommodations & dining
            </p>
          </motion.div>

          {/* Connecting Line Visual */}
          <div className="hidden md:block absolute left-1/2 top-[600px] bottom-96 w-1 bg-gradient-to-b from-temple-gold via-temple-saffron to-temple-bronze opacity-30 -translate-x-1/2" />

          {templeLocations.map((loc, index) => (
            <motion.div
              key={loc.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + index * 0.15 }}
              className="relative"
            >
              {/* Node Connector */}
              <div className="hidden md:flex absolute -left-4 top-8 w-8 h-8 rounded-full bg-temple-gold items-center justify-center text-foreground font-heading font-bold shadow-lg z-10">
                {index + 1}
              </div>

              <Card variant="parchment" className="overflow-hidden border-2 border-temple-bronze/30 ml-0 md:ml-8">
                {/* Header with Image */}
                <div className="md:flex">
                  <div className="md:w-1/3 relative">
                    <img
                      src={loc.image}
                      alt={loc.name}
                      className="w-full h-56 md:h-full object-cover"
                    />
                    <div className="absolute top-3 left-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-heading ${
                        loc.category === "temple" 
                          ? "bg-temple-gold/90 text-foreground" 
                          : "bg-temple-bronze/90 text-primary-foreground"
                      }`}>
                        {loc.category === "temple" ? "🛕 Temple" : "🏛 Heritage"}
                      </span>
                    </div>
                    <div className="absolute bottom-3 left-3 right-3">
                      <span className="px-3 py-1 bg-background/90 backdrop-blur-sm rounded-lg text-xs font-body flex items-center gap-2">
                        <MapPin className="h-3 w-3 text-temple-bronze" />
                        {loc.location}
                      </span>
                    </div>
                  </div>

                  <div className="md:w-2/3 p-5">
                    <div className="flex flex-wrap justify-between items-start gap-3 mb-4">
                      <div>
                        <h3 className="text-xl md:text-2xl font-heading font-bold text-primary">
                          {getTranslatedContent(loc.id)?.name || loc.name}
                        </h3>
                      </div>
                      <VoiceReader 
                        text={`${getTranslatedContent(loc.id)?.name || loc.name}. ${getTranslatedContent(loc.id)?.history || loc.history}`} 
                        language={getSpeechLang()}
                      />
                    </div>

                    {/* Facilities Icons */}
                    <div className="flex flex-wrap gap-3 mb-4 py-2 border-y border-border">
                      {Object.entries(loc.facilities).map(([key, value]) => (
                        <FacilityIcon key={key} type={key} active={value as boolean} />
                      ))}
                    </div>

                    {/* Expand/Collapse Button */}
                    <Button
                      variant="ghost"
                      className="w-full justify-between text-temple-bronze hover:text-primary"
                      onClick={() => setExpandedId(expandedId === loc.id ? null : loc.id)}
                    >
                      <span className="font-heading flex items-center gap-2">
                        <Map className="h-4 w-4" />
                        {expandedId === loc.id ? "Hide Details" : "View Complete Details"}
                      </span>
                      {expandedId === loc.id ? (
                        <ChevronUp className="h-5 w-5" />
                      ) : (
                        <ChevronDown className="h-5 w-5" />
                      )}
                    </Button>

                    {/* Expanded Content - Hierarchical Structure */}
                    <AnimatePresence>
                      {expandedId === loc.id && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.3 }}
                          className="overflow-hidden"
                        >
                          <div className="pt-4 space-y-6 border-t border-temple-gold/30 mt-4">
                            {/* History & Significance */}
                            <div className="space-y-2">
                              <h4 className="font-heading font-semibold text-primary flex items-center gap-2">
                                <span className="text-lg">📜</span> History & Significance
                              </h4>
                              <p className="font-body text-foreground/90 leading-relaxed pl-7">
                                {getTranslatedContent(loc.id)?.history || loc.history}
                              </p>
                            </div>

                            {/* Visiting Hours */}
                            <div className="space-y-2">
                              <h4 className="font-heading font-semibold text-primary flex items-center gap-2">
                                <Clock className="h-5 w-5 text-temple-saffron" /> Visiting Hours
                              </h4>
                              <div className="pl-7 space-y-1">
                                <p className="font-body text-foreground/90">
                                  <span className="font-medium">General:</span> {getTranslatedContent(loc.id)?.visitingHours?.general || loc.visitingHours.general}
                                </p>
                                {(getTranslatedContent(loc.id)?.visitingHours?.special || loc.visitingHours.special) && (
                                  <p className="font-body text-temple-bronze">
                                    <span className="font-medium">Special:</span> {getTranslatedContent(loc.id)?.visitingHours?.special || loc.visitingHours.special}
                                  </p>
                                )}
                              </div>
                            </div>

                            {/* Hotels & Stays */}
                            <div className="space-y-2">
                              <h4 className="font-heading font-semibold text-primary flex items-center gap-2">
                                <Hotel className="h-5 w-5 text-temple-saffron" /> Hotels & Stays
                              </h4>
                              <div className="pl-7 grid grid-cols-1 sm:grid-cols-2 gap-2">
                                {loc.hotels.map((hotel, idx) => (
                                  <div key={idx} className="bg-muted/50 rounded-lg p-3 border border-border">
                                    <p className="font-body font-medium text-foreground">{hotel.name}</p>
                                    <p className="font-body text-sm text-temple-bronze flex items-center gap-1">
                                      <Phone className="h-3 w-3" /> {hotel.contact}
                                    </p>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {/* Restaurants */}
                            <div className="space-y-2">
                              <h4 className="font-heading font-semibold text-primary flex items-center gap-2">
                                <Utensils className="h-5 w-5 text-temple-saffron" /> Restaurants & Food
                              </h4>
                              <ul className="pl-7 space-y-1">
                                {loc.restaurants.map((restaurant, idx) => (
                                  <li key={idx} className="font-body text-foreground/90 flex items-start gap-2">
                                    <span className="text-temple-gold mt-1">•</span>
                                    {restaurant}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="text-center py-12"
        >
          <p className="text-muted-foreground font-body italic">
            "May your pilgrimage bring peace, prosperity, and divine blessings"
          </p>
          <div className="mt-4 flex justify-center items-center gap-2">
            <span className="text-2xl">🙏</span>
            <span className="h-px w-12 bg-temple-gold" />
            <span className="text-2xl">🛕</span>
            <span className="h-px w-12 bg-temple-gold" />
            <span className="text-2xl">🙏</span>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Route;
