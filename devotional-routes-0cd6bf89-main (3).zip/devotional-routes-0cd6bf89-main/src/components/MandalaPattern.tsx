import { motion } from "framer-motion";

const MandalaPattern = ({ className = "" }: { className?: string }) => {
  return (
    <div className={`absolute inset-0 overflow-hidden pointer-events-none ${className}`}>
      <motion.div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
        animate={{ rotate: 360 }}
        transition={{ duration: 120, repeat: Infinity, ease: "linear" }}
      >
        <svg
          viewBox="0 0 400 400"
          className="w-[800px] h-[800px] opacity-[0.08]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="mandalaGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#c4a052" />
              <stop offset="100%" stopColor="#8b6914" />
            </linearGradient>
          </defs>
          
          {/* Outer circles */}
          {[180, 160, 140, 120, 100, 80, 60, 40].map((r, i) => (
            <circle
              key={i}
              cx="200"
              cy="200"
              r={r}
              stroke="url(#mandalaGrad)"
              strokeWidth="0.5"
              fill="none"
            />
          ))}
          
          {/* Petal patterns */}
          {Array.from({ length: 12 }).map((_, i) => (
            <g key={`petal-${i}`} transform={`rotate(${i * 30} 200 200)`}>
              <path
                d="M200 20 Q220 100 200 180 Q180 100 200 20"
                stroke="url(#mandalaGrad)"
                strokeWidth="0.5"
                fill="none"
              />
              <path
                d="M200 50 Q210 100 200 150"
                stroke="url(#mandalaGrad)"
                strokeWidth="0.3"
                fill="none"
              />
            </g>
          ))}
          
          {/* Inner lotus pattern */}
          {Array.from({ length: 8 }).map((_, i) => (
            <g key={`lotus-${i}`} transform={`rotate(${i * 45} 200 200)`}>
              <ellipse
                cx="200"
                cy="160"
                rx="15"
                ry="40"
                stroke="url(#mandalaGrad)"
                strokeWidth="0.5"
                fill="none"
              />
            </g>
          ))}
          
          {/* Center flower */}
          <circle cx="200" cy="200" r="20" stroke="url(#mandalaGrad)" strokeWidth="1" fill="none" />
          <circle cx="200" cy="200" r="10" fill="url(#mandalaGrad)" opacity="0.3" />
        </svg>
      </motion.div>
    </div>
  );
};

export default MandalaPattern;
