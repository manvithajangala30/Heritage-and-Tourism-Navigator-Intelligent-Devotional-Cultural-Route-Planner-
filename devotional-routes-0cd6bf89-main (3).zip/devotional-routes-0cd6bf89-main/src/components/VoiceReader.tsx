import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Play, Pause, Square, Volume2 } from "lucide-react";
import { motion } from "framer-motion";

interface VoiceReaderProps {
  text: string;
  className?: string;
  language?: string; // Speech synthesis language code (e.g., "en-IN", "te-IN", "hi-IN")
}

const VoiceReader = ({ text, className = "", language = "en-IN" }: VoiceReaderProps) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    return () => {
      window.speechSynthesis.cancel();
    };
  }, []);

  // Reset when text or language changes
  useEffect(() => {
    window.speechSynthesis.cancel();
    setIsPlaying(false);
    setIsPaused(false);
  }, [text, language]);

  const handlePlay = () => {
    if (isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
      setIsPlaying(true);
      return;
    }

    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.85;
    utterance.pitch = 1;
    utterance.volume = 1;
    utterance.lang = language;
    
    // Find a voice matching the language
    const voices = window.speechSynthesis.getVoices();
    const langPrefix = language.split('-')[0];
    const preferredVoice = voices.find(v => v.lang === language) 
      || voices.find(v => v.lang.startsWith(langPrefix));
    
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }

    utterance.onend = () => {
      setIsPlaying(false);
      setIsPaused(false);
    };

    utterance.onerror = () => {
      setIsPlaying(false);
      setIsPaused(false);
    };

    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
    setIsPlaying(true);
  };

  const handlePause = () => {
    window.speechSynthesis.pause();
    setIsPaused(true);
    setIsPlaying(false);
  };

  const handleStop = () => {
    window.speechSynthesis.cancel();
    setIsPlaying(false);
    setIsPaused(false);
  };

  return (
    <motion.div
      className={`flex items-center gap-2 ${className}`}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
    >
      <div className="flex items-center gap-1 bg-temple-bronze/10 rounded-full p-1">
        {!isPlaying ? (
          <Button
            variant="voice"
            size="icon"
            onClick={handlePlay}
            className="rounded-full"
            title={isPaused ? "Resume" : "Play"}
          >
            <Play className="h-4 w-4" />
          </Button>
        ) : (
          <Button
            variant="voice"
            size="icon"
            onClick={handlePause}
            className="rounded-full"
            title="Pause"
          >
            <Pause className="h-4 w-4" />
          </Button>
        )}
        <Button
          variant="ghost"
          size="icon"
          onClick={handleStop}
          disabled={!isPlaying && !isPaused}
          className="rounded-full text-temple-bronze hover:bg-temple-bronze/20"
          title="Stop"
        >
          <Square className="h-4 w-4" />
        </Button>
      </div>
      
      {(isPlaying || isPaused) && (
        <motion.div
          className="flex items-center gap-1"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <Volume2 className="h-4 w-4 text-temple-bronze" />
          <div className="flex gap-0.5">
            {[1, 2, 3].map((i) => (
              <motion.div
                key={i}
                className="w-1 bg-temple-gold rounded-full"
                animate={isPlaying ? {
                  height: [8, 16, 8],
                } : { height: 8 }}
                transition={{
                  duration: 0.5,
                  repeat: isPlaying ? Infinity : 0,
                  delay: i * 0.1,
                }}
              />
            ))}
          </div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default VoiceReader;
