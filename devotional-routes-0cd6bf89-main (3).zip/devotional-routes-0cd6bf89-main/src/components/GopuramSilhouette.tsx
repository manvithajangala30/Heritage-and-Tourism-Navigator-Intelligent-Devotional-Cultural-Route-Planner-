import { motion } from "framer-motion";

const GopuramSilhouette = ({ className = "" }: { className?: string }) => {
  return (
    <motion.div
      className={`absolute bottom-0 left-0 right-0 pointer-events-none ${className}`}
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 1, delay: 0.5 }}
    >
      <svg
        viewBox="0 0 1200 400"
        className="w-full h-auto opacity-10"
        preserveAspectRatio="xMidYMax slice"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="gopuramGrad" x1="50%" y1="0%" x2="50%" y2="100%">
            <stop offset="0%" stopColor="#5c2018" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#5c2018" stopOpacity="0.2" />
          </linearGradient>
        </defs>
        
        {/* Left temple */}
        <path
          d="M50 400 L50 300 L30 300 L30 250 L50 250 L50 200 L70 200 L70 180 L60 180 L60 150 L80 150 L80 130 L70 120 L90 100 L100 120 L110 100 L120 120 L130 110 L140 130 L130 140 L150 160 L150 180 L140 180 L140 200 L160 200 L160 250 L180 250 L180 300 L160 300 L160 400"
          fill="url(#gopuramGrad)"
        />
        
        {/* Center main gopuram */}
        <path
          d="M500 400 L500 320 L480 320 L480 280 L500 280 L500 240 L520 240 L520 200 L510 200 L510 160 L530 160 L530 130 L520 130 L520 100 L540 100 L540 80 L530 70 L550 50 L560 30 L570 10 L580 30 L590 50 L610 70 L600 80 L600 100 L620 100 L620 130 L610 130 L610 160 L630 160 L630 200 L620 200 L620 240 L640 240 L640 280 L660 280 L660 320 L640 320 L640 400"
          fill="url(#gopuramGrad)"
        />
        
        {/* Right temple */}
        <path
          d="M1000 400 L1000 280 L980 280 L980 240 L1000 240 L1000 200 L1020 200 L1020 170 L1010 160 L1030 140 L1040 150 L1050 140 L1060 150 L1070 140 L1090 160 L1080 170 L1080 200 L1100 200 L1100 240 L1120 240 L1120 280 L1100 280 L1100 400"
          fill="url(#gopuramGrad)"
        />
        
        {/* Small temples */}
        <path
          d="M250 400 L250 350 L240 340 L260 320 L270 330 L280 320 L300 340 L290 350 L290 400"
          fill="url(#gopuramGrad)"
        />
        <path
          d="M800 400 L800 360 L790 350 L810 330 L820 340 L830 330 L850 350 L840 360 L840 400"
          fill="url(#gopuramGrad)"
        />
      </svg>
    </motion.div>
  );
};

export default GopuramSilhouette;
