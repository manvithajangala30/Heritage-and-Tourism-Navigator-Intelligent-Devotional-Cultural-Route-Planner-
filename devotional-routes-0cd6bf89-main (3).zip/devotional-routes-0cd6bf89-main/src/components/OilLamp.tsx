import { motion } from "framer-motion";

const OilLamp = ({ className = "", delay = 0 }: { className?: string; delay?: number }) => {
  return (
    <motion.div
      className={`relative ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5 }}
    >
      <motion.div
        className="relative"
        animate={{ y: [0, -8, 0] }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
      >
        {/* Lamp Base */}
        <svg
          viewBox="0 0 100 120"
          className="w-16 h-20 drop-shadow-lg"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Glow effect */}
          <defs>
            <radialGradient id="lampGlow" cx="50%" cy="30%" r="50%">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#f59e0b" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="brassGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#d4a574" />
              <stop offset="50%" stopColor="#c4a052" />
              <stop offset="100%" stopColor="#a67c3d" />
            </linearGradient>
          </defs>
          
          {/* Glow circle */}
          <motion.circle
            cx="50"
            cy="25"
            r="30"
            fill="url(#lampGlow)"
            animate={{ opacity: [0.6, 1, 0.6], scale: [1, 1.1, 1] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          />
          
          {/* Flame */}
          <motion.path
            d="M50 10 C45 20 42 25 45 35 C47 40 50 42 50 42 C50 42 53 40 55 35 C58 25 55 20 50 10"
            fill="#f59e0b"
            animate={{ 
              scaleY: [1, 0.95, 1.02, 0.98, 1],
              opacity: [1, 0.9, 1, 0.95, 1]
            }}
            transition={{ duration: 0.5, repeat: Infinity }}
          />
          <motion.path
            d="M50 15 C47 22 46 26 48 32 C49 35 50 36 50 36 C50 36 51 35 52 32 C54 26 53 22 50 15"
            fill="#fbbf24"
            animate={{ 
              scaleY: [1, 1.05, 0.95, 1],
            }}
            transition={{ duration: 0.3, repeat: Infinity }}
          />
          
          {/* Lamp body */}
          <ellipse cx="50" cy="50" rx="25" ry="8" fill="url(#brassGradient)" />
          <path
            d="M25 50 Q20 70 30 85 L70 85 Q80 70 75 50"
            fill="url(#brassGradient)"
          />
          <ellipse cx="50" cy="85" rx="20" ry="6" fill="url(#brassGradient)" />
          
          {/* Stand */}
          <rect x="45" y="91" width="10" height="15" fill="url(#brassGradient)" />
          <ellipse cx="50" cy="110" rx="18" ry="5" fill="url(#brassGradient)" />
        </svg>
      </motion.div>
    </motion.div>
  );
};

export default OilLamp;
