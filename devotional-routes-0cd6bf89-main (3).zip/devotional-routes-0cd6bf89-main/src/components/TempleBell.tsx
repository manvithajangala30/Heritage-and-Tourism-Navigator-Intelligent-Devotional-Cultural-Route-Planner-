import { motion } from "framer-motion";

const TempleBell = ({ className = "", delay = 0 }: { className?: string; delay?: number }) => {
  return (
    <motion.div
      className={`relative ${className}`}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay, duration: 0.5 }}
    >
      <motion.div
        animate={{ rotate: [-5, 5, -5] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        style={{ transformOrigin: "top center" }}
      >
        <svg
          viewBox="0 0 60 100"
          className="w-12 h-20"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="bellGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#d4a574" />
              <stop offset="50%" stopColor="#c4a052" />
              <stop offset="100%" stopColor="#8b6914" />
            </linearGradient>
          </defs>
          
          {/* Chain/Hook */}
          <circle cx="30" cy="8" r="6" stroke="url(#bellGradient)" strokeWidth="3" fill="none" />
          <rect x="28" y="14" width="4" height="12" fill="url(#bellGradient)" />
          
          {/* Bell top */}
          <ellipse cx="30" cy="30" rx="8" ry="4" fill="url(#bellGradient)" />
          
          {/* Bell body */}
          <path
            d="M10 75 Q8 50 22 32 L38 32 Q52 50 50 75"
            fill="url(#bellGradient)"
          />
          <ellipse cx="30" cy="75" rx="20" ry="6" fill="url(#bellGradient)" />
          
          {/* Clapper */}
          <motion.g
            animate={{ x: [-2, 2, -2] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          >
            <rect x="28" y="45" width="4" height="25" fill="#8b6914" />
            <circle cx="30" cy="75" r="6" fill="#8b6914" />
          </motion.g>
        </svg>
      </motion.div>
    </motion.div>
  );
};

export default TempleBell;
