import { Button } from "@/components/ui/button";
import { languages, Language } from "@/data/templeTranslations";
import { Globe } from "lucide-react";
import { motion } from "framer-motion";

interface LanguageSelectorProps {
  selectedLanguage: Language;
  onLanguageChange: (language: Language) => void;
  className?: string;
}

const LanguageSelector = ({ selectedLanguage, onLanguageChange, className = "" }: LanguageSelectorProps) => {
  return (
    <motion.div
      className={`flex items-center gap-2 ${className}`}
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
    >
      <Globe className="h-5 w-5 text-temple-bronze" />
      <div className="flex gap-1 bg-temple-bronze/10 rounded-full p-1">
        {languages.map((lang) => (
          <Button
            key={lang.code}
            variant={selectedLanguage === lang.code ? "gold" : "ghost"}
            size="sm"
            onClick={() => onLanguageChange(lang.code)}
            className={`rounded-full px-3 py-1 text-sm font-heading transition-all ${
              selectedLanguage === lang.code 
                ? "" 
                : "text-temple-bronze hover:text-primary hover:bg-temple-bronze/20"
            }`}
          >
            <span className="hidden sm:inline">{lang.nativeLabel}</span>
            <span className="sm:hidden">{lang.code.slice(0, 2).toUpperCase()}</span>
          </Button>
        ))}
      </div>
    </motion.div>
  );
};

export default LanguageSelector;
